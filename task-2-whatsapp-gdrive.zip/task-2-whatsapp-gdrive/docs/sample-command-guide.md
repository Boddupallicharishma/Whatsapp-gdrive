# 📲 WhatsApp Command Examples

Use these via your Twilio WhatsApp Sandbox:

- `LIST /ProjectX`  
- `DELETE /ProjectX/report.pdf`  
- `MOVE /ProjectX/file.pdf /Archive`  
- `SUMMARY /ProjectX`

Ensure your Google Drive contains sample folders/files.
